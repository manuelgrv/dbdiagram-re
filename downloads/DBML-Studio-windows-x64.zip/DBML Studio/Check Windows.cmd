@echo off
setlocal
"%~dp0resources\node.exe" "%~dp0resources\project\check-windows.mjs"
set "DBML_CHECK_RESULT=%ERRORLEVEL%"
pause
exit /b %DBML_CHECK_RESULT%
