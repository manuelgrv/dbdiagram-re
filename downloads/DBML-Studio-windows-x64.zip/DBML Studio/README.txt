DBML Studio for Windows x64

Extract the entire ZIP, then double-click DBML Studio.exe.
No Node.js, npm, VS Code, administrator rights, or installer required.
The browser opens automatically. Open folder selects a workspace using the native Windows picker.
Use the DBML Studio notification-area (tray) icon to reopen Studio or Quit. It may appear under the hidden-icons arrow.
Closing the browser keeps the server running; Quit stops it.
The last workspace is stored under %LOCALAPPDATA%\DBML Studio.
Run Check Windows.cmd for an automated backend smoke test.
Studio CLI.cmd [DIRECTORY] starts the bundled backend in a terminal; Ctrl+C stops it.

This is an unsigned portable build targeting Windows 10/11 x64.
Cross-compiled on macOS. Windows GUI execution is not automatically verified by packaging.
The original renderer/package notices, Node license, and compiler provenance are included.
