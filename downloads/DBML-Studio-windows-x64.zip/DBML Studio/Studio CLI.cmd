@echo off
setlocal
set "DBDIAGRAM_EXTENSION_DIR=%~dp0resources\extension"
set "ACORN_PATH=%~dp0resources\vendor\acorn.cjs"
"%~dp0resources\node.exe" "%~dp0resources\project\launch.mjs" %*
