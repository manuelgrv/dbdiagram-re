# Change Log

All notable changes to the "dbdiagram-vscode" extension will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.4.0] - 2026-08-18

### Added

- Support data dependencies (`Dep`) in the preview panel

### Changed

- Bump `@dbml/core` to v10.1.1
- Raise the `.dbdiagram` file to version 3.0.0.

## [0.3.4] - 2026-07-31

### Added

- Support custom metadata

## [0.3.3] - 2026-07-30

### Added

- Support optional refs

## [0.3.2] - 2026-06-30

### Fixed

- Fix additional DiagramView blocks not rendering after upgrading `@dbml/core` to v8

## [0.3.1] - 2026-06-29

### Fixed

- Fix some markdown rendering & interaction issues in sticky note and tooltip

## [0.3.0] - 2026-06-22

### Added

- Support sticky note color and markdown in tooltip/sticky note

## [0.2.1] - 2026-05-12

### Fixed

- No longer show the premium feature notification to PRO users at activation (now waits for subscription check to complete).
- Diagram now renders in the correct dark mode on first paint.
- Fix render bug for larger diagrams (race conditionbetween data arrival and the renderer's init).
- Fix late PRO/FREE feature-toggle updates being dropped when they land mid-init.
- Camera auto-focuses on the new view's content when switching DiagramViews.

## [0.2.0] - 2026-05-11

### Added

- Support DiagramView in preview panel
- Show syntax errors in preview panel
- Added premium feature notification and setting

## [0.1.5] - 2026-04-23

### Added

- Support DiagramView syntax languague side (not yet supported in the preview model)

### Misc

- Resolves various security issues

## [0.1.4] - 2026-04-17

### Misc

- Improve data sample modal: handle composite keys better

## [0.1.3] - 2026-04-13

### Added

- Improve data sample modal: support jumping to referenced table and downloading CSV files

## [0.1.2] - 2026-03-30

### Added

- Support data sample syntax

### Changed

- Upgrade `@dbml/core` to v6

## [0.1.1] - 2025-12-19

### Added

- Add instruction to login

## [0.1.0] - 2025-12-19

### Added

- Implement code authorization flow with PKCE
- Implement fetching features toggle to enable Pro features

### Changed

- Change extension entrypoint to `extension.ts`

## [0.0.8] - 2025-12-12

### Fixed

- Correct typo in README

## [0.0.7] - 2025-12-12

### Changed

- Update license

## [0.0.6] - 2025-12-11

### Changed

- Reduce require vscode version to 1.95.0

## [0.0.5] - 2025-11-19

### Changed

- Update usage instructions in README

## [0.0.4] - 2025-11-14

### Added

- Command to generate DBML from database connection string
- Dark mode sync with VSCode theme

## [0.0.3] - 2025-11-13

### Added

- DBML Error diagnostics
- DBML Syntax highlighting

### Changed

- Automatic save/load diagram preview layout in .dbdiagram file

### Fixed

- Fix broken panning icon tooltips layout in diagram preview

## [0.0.2] - 2025-11-12

### Added

- Update extensions icon

## [0.0.1] - 2025-11-12

### Added

- Initial release
