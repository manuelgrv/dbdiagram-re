# dbdiagram VS Code Extension

The official VS Code extension from dbdiagram.io. It provides real-time visualization of Entity-Relationship Diagrams (ERDs) and data lineage for DBML (Database Markup Language) files.

## Features

 - **ERD Visualization**: View Entity-Relationship Diagrams (ERDs) directly in VS Code while editing DBML files.
 - **Data Lineage**: Draw dependency (`Dep`) lines alongside relationships, and switch between relationships, dependencies, or both with the Link type control.
 - **DBML Support**: Full syntax highlighting and editor support for `.dbml` files.
 - **Generate DBML From a Database Connection**: Generate DBML from a database connection to visualize the database.

![dbdiagram VS Code Extension](https://media.holistics.io/efddcae7-dbdiagram-vs-code-extension.gif)

## Usage

See the [extension documentation](https://docs.dbdiagram.io/vs-code-extension/) to learn more.

### Opening the Preview

When you have a `.dbml` file open, you can view the ERD in two ways:

1. **Editor Button**: Click the preview icon in the editor title bar (visible when a `.dbml` file is open).
2. **Command Palette**: Open the command palette (`Cmd+Shift+P` on macOS or `Ctrl+Shift+P` on Windows/Linux) and search for "DBML: Open Preview to the Side".

### Editing

Simply edit your DBML file in the editor — the diagram updates automatically as you make changes.

### Login for Paid Features

For users with paid plans, to access premium features, log in with your dbdiagram.io account. There are two ways to login:

1. **Command Palette**: Open the command palette (`Cmd+Shift+P` on macOS or `Ctrl+Shift+P` on Windows/Linux) and search for "Login with dbdiagram".
2. **VSCode Manage Accounts**: Click on the account icon in the bottom left corner of VSCode, then select "Sign in with dbdiagram to use dbdiagram".

Once logged in, paid features will be automatically enabled.

**Note**: Network connectivity is required to access paid features.

## DBML Syntax

This extension supports the full DBML syntax. For more information about DBML syntax and how to write database schemas, visit the [DBML Documentation](https://dbml.dbdiagram.io/).

Example DBML:

```dbml
Table users {
  id int [primary key]
  email varchar [unique]
  created_at timestamp
}

Table posts {
  id int [primary key]
  user_id int [ref: > users.id]
  title varchar
  content text
}
```

## DBML Reference

This extension supports the full DBML specification. For details and advanced syntax, see the [DBML Documentation](https://dbml.dbdiagram.io/).

## Support & feedback

- **Report issues**: Report bugs or problems on the community forum: https://community.dbdiagram.io/c/report-bugs/17.
- **Feature requests**: Suggest features on the community forum: https://community.dbdiagram.io/c/feature-suggestions/16.
